package projetoyoutube;

/**
 *
 * @author angela
 */
public interface AcoesVideo {
    public void play();
    public void pause();
    public void like();
    
}
